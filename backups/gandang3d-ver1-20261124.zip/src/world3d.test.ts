import test from 'node:test';
import assert from 'node:assert/strict';
import {canWalk,findRoute} from './world3d.ts';
test('3D village blocks buildings, water and boundary while keeping plaza open',()=>{
  assert.equal(canWalk({x:0,z:4}),true);
  for(const p of [{x:-7,z:-4},{x:8,z:6},{x:7,z:-5},{x:18,z:0},{x:NaN,z:0}])assert.equal(canWalk(p),false);
});
test('click route goes around a solid hanok footprint',()=>{
  const route=findRoute({x:-7,z:3},{x:-7,z:-9});
  assert.ok(route.length>10);assert.ok(route.every(canWalk));
  assert.deepEqual(route.at(-1),{x:-7,z:-9});
  assert.deepEqual(findRoute({x:0,z:0},{x:7,z:-5}),[]);
});
