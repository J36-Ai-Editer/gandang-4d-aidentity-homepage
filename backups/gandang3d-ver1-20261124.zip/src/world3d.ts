export type Position = { x:number; z:number };
export type Obstacle = { x:number; z:number; width:number; depth:number };
export const BUILDINGS:Obstacle[] = [
  {x:-7,z:-4,width:7,depth:5},
  {x:8,z:6,width:5.5,depth:4},
  {x:-5,z:-14,width:6,depth:4},
];
export function canWalk(p:Position):boolean {
  if(!Number.isFinite(p.x)||!Number.isFinite(p.z)||Math.abs(p.x)>17||p.z < -17||p.z>17)return false;
  if(((p.x-7)/5.4)**2+((p.z+5)/4.5)**2<1)return false;
  if(BUILDINGS.some(b=>Math.abs(p.x-b.x)<b.width/2+.4&&Math.abs(p.z-b.z)<b.depth/2+.4))return false;
  return ![{x:-12,z:3},{x:-10,z:11},{x:12,z:-11},{x:13,z:11}].some(t=>Math.hypot(p.x-t.x,p.z-t.z)<.9);
}
export function findRoute(from:Position,to:Position):Position[] {
  if(!canWalk(to))return [];
  const step=.5, key=(p:Position)=>`${p.x},${p.z}`;
  const start={x:Math.round(from.x/step),z:Math.round(from.z/step)};
  const goal={x:Math.round(to.x/step),z:Math.round(to.z/step)};
  const queue=[start],parent=new Map<string,Position|null>([[key(start),null]]);
  for(let i=0;i<queue.length;i++){
    const current=queue[i];
    if(key(current)===key(goal)){
      const result:Position[]=[to];let p:Position|null=current;
      while(p){result.push({x:p.x*step,z:p.z*step});p=parent.get(key(p))??null;}
      result.reverse();result.shift();return result;
    }
    for(const [x,z] of [[1,0],[-1,0],[0,1],[0,-1]]){
      const next={x:current.x+x,z:current.z+z};
      if(parent.has(key(next))||!canWalk({x:next.x*step,z:next.z*step}))continue;
      parent.set(key(next),current);queue.push(next);
    }
  }
  return [];
}
